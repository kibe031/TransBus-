from django.db import models
from django.contrib.auth.models import User

class Driver(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    surname = models.CharField(max_length=100)
    middle_name = models.CharField(max_length=100)
    phone_number = models.CharField(max_length=15)
    national_id = models.CharField(max_length=20)
    dl_number = models.CharField(max_length=20)
    dl_class = models.CharField(max_length=10)
    is_approved = models.BooleanField(default=False)
    wallet_balance = models.DecimalField(max_digits=10, decimal_places=2, default=0.00)

class Customer(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    surname = models.CharField(max_length=100)
    middle_name = models.CharField(max_length=100)
    phone_number = models.CharField(max_length=15)

class Route(models.Model):
    name = models.CharField(max_length=100)
    description = models.TextField()

class Checkpoint(models.Model):
    route = models.ForeignKey(Route, on_delete=models.CASCADE)
    name = models.CharField(max_length=100)
    latitude = models.FloatField()
    longitude = models.FloatField()
    order = models.IntegerField()

class Bus(models.Model):
    name = models.CharField(max_length=100)
    route = models.ForeignKey(Route, on_delete=models.CASCADE)
    driver = models.ForeignKey(Driver, on_delete=models.SET_NULL, null=True, blank=True)

class Fare(models.Model):
    start_checkpoint = models.ForeignKey(Checkpoint, on_delete=models.CASCADE, related_name='start_fares')
    end_checkpoint = models.ForeignKey(Checkpoint, on_delete=models.CASCADE, related_name='end_fares')
    amount = models.DecimalField(max_digits=10, decimal_places=2)

class Payment(models.Model):
    customer = models.ForeignKey(Customer, on_delete=models.CASCADE)
    bus = models.ForeignKey(Bus, on_delete=models.CASCADE)
    amount = models.DecimalField(max_digits=10, decimal_places=2)
    timestamp = models.DateTimeField(auto_now_add=True)
    start_checkpoint = models.ForeignKey(Checkpoint, on_delete=models.CASCADE, related_name='start_payments')
    end_checkpoint = models.ForeignKey(Checkpoint, on_delete=models.CASCADE, related_name='end_payments')

class DriverRating(models.Model):
    driver = models.ForeignKey(Driver, on_delete=models.CASCADE)
    customer = models.ForeignKey(Customer, on_delete=models.CASCADE)
    rating = models.IntegerField(choices=[(i, i) for i in range(1, 6)])  # 1 to 5 stars
    comment = models.TextField(blank=True)
    timestamp = models.DateTimeField(auto_now_add=True)

class Complaint(models.Model):
        STATUS_CHOICES = [
            ('PENDING', 'Pending'),
            ('IN_PROGRESS', 'In Progress'),
            ('RESOLVED', 'Resolved'),
        ]
        customer = models.ForeignKey(Customer, on_delete=models.CASCADE)
        driver = models.ForeignKey(Driver, on_delete=models.SET_NULL, null=True, blank=True)
        description = models.TextField()
        status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='PENDING')
        resolution_notes = models.TextField(blank=True)
        timestamp = models.DateTimeField(auto_now_add=True)
        updated_at = models.DateTimeField(auto_now=True)