from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.models import User
from django.contrib import messages
from .models import Driver, Customer, Route, Checkpoint, Bus, Fare, Payment, DriverRating, Complaint
from django.contrib.auth.decorators import login_required
import json
from django.db.models import Avg

def home(request):
    return render(request, 'home.html')

# Admin Views
def admin_register(request):
    if request.method == 'POST':
        username = request.POST['username']
        email = request.POST['email']
        password = request.POST['password']
        password_confirm = request.POST['password_confirm']
        if password == password_confirm:
            try:
                user = User.objects.create_user(username, email, password)
                user.is_staff = True
                user.save()
                messages.success(request, 'Admin registered successfully')
                return redirect('transport:admin_login')
            except:
                messages.error(request, 'Error registering admin')
        else:
            messages.error(request, 'Passwords do not match')
    return render(request, 'admin/register.html')

def admin_login(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username=username, password=password)
        if user is not None and user.is_staff:
            login(request, user)
            return redirect('transport:admin_dashboard')
        messages.error(request, 'Invalid credentials or not an admin')
    return render(request, 'admin/login.html')

def admin_logout(request):
    logout(request)
    return render(request, 'admin/logout.html')

@login_required
def admin_dashboard(request):
    if not request.user.is_staff:
        return redirect('transport:home')
    return render(request, 'admin/admin_dashboard.html')

@login_required
def driver_approval(request):
    if not request.user.is_staff:
        return redirect('transport:home')
    drivers = Driver.objects.all()
    if request.method == 'POST':
        driver_id = request.POST.get('driver_id')
        action = request.POST.get('action')
        driver = Driver.objects.get(id=driver_id)
        if action == 'approve':
            driver.is_approved = True
            driver.save()
            messages.success(request, 'Driver approved')
        elif action == 'disapprove':
            driver.is_approved = False
            driver.save()
            messages.success(request, 'Driver disapproved')
    return render(request, 'admin/driver_approval.html', {'drivers': drivers})

@login_required
def driver_removal(request):
    if not request.user.is_staff:
        return redirect('transport:home')
    drivers = Driver.objects.all()
    if request.method == 'POST':
        driver_id = request.POST.get('driver_id')
        driver = Driver.objects.get(id=driver_id)
        driver.user.delete()
        messages.success(request, 'Driver removed')
    return render(request, 'admin/driver_removal.html', {'drivers': drivers})

@login_required
def admin_map(request):
    if not request.user.is_staff:
        return redirect('transport:home')
    routes = Route.objects.all()
    checkpoints = Checkpoint.objects.all()
    buses = Bus.objects.all()
    return render(request, 'admin/map.html', {
        'routes': routes,
        'checkpoints': checkpoints,
        'buses': buses
    })

@login_required
def route_checkpoint(request):
    if not request.user.is_staff:
        return redirect('transport:home')
    if request.method == 'POST':
        if 'route_name' in request.POST:
            Route.objects.create(
                name=request.POST['route_name'],
                description=request.POST['description']
            )
            messages.success(request, 'Route created')
        elif 'checkpoint_name' in request.POST:
            Checkpoint.objects.create(
                route_id=request.POST['route_id'],
                name=request.POST['checkpoint_name'],
                latitude=float(request.POST['latitude']),
                longitude=float(request.POST['longitude']),
                order=int(request.POST['order'])
            )
            messages.success(request, 'Checkpoint created')
        elif 'bus_name' in request.POST:
            Bus.objects.create(
                name=request.POST['bus_name'],
                route_id=request.POST['route_id']
            )
            messages.success(request, 'Bus created')
        elif 'fare_amount' in request.POST:
            Fare.objects.create(
                start_checkpoint_id=request.POST['start_checkpoint'],
                end_checkpoint_id=request.POST['end_checkpoint'],
                amount=float(request.POST['fare_amount'])
            )
            messages.success(request, 'Fare created')
    routes = Route.objects.all()
    checkpoints = Checkpoint.objects.all()
    return render(request, 'admin/route_checkpoint.html', {
        'routes': routes,
        'checkpoints': checkpoints
    })

@login_required
def assign_bus(request):
    if not request.user.is_staff:
        return redirect('transport:home')
    if request.method == 'POST':
        bus_id = request.POST['bus_id']
        driver_id = request.POST['driver_id']
        bus = Bus.objects.get(id=bus_id)
        driver = Driver.objects.get(id=driver_id)
        bus.driver = driver
        bus.save()
        messages.success(request, 'Bus assigned to driver')
    buses = Bus.objects.all()
    drivers = Driver.objects.filter(is_approved=True)
    return render(request, 'admin/assign_bus.html', {'buses': buses, 'drivers': drivers})

@login_required
def revenue(request):
    if not request.user.is_staff:
        return redirect('transport:home')
    payments = Payment.objects.all()
    total_revenue = sum(payment.amount for payment in payments)
    return render(request, 'admin/revenue.html', {'payments': payments, 'total_revenue': total_revenue})

@login_required
def admin_ratings(request):
    if not request.user.is_staff:
        return redirect('transport:home')
    ratings = DriverRating.objects.all()
    drivers = Driver.objects.all()
    # Prepare data for chart
    chart_data = []
    for driver in drivers:
        avg_rating = DriverRating.objects.filter(driver=driver).aggregate(Avg('rating'))['rating__avg'] or 0
        chart_data.append({
            'driver': driver.user.username,
            'avg_rating': round(avg_rating, 2)
        })
    return render(request, 'admin/ratings.html', {
        'ratings': ratings,
        'chart_data': json.dumps(chart_data)
    })

@login_required
def admin_complaints(request):
    if not request.user.is_staff:
        return redirect('transport:home')
    complaints = Complaint.objects.all()
    if request.method == 'POST':
        complaint_id = request.POST['complaint_id']
        status = request.POST['status']
        resolution_notes = request.POST['resolution_notes']
        complaint = Complaint.objects.get(id=complaint_id)
        complaint.status = status
        complaint.resolution_notes = resolution_notes
        complaint.save()
        messages.success(request, 'Complaint updated')
    return render(request, 'admin/complaints.html', {'complaints': complaints})

# Driver Views
def driver_register(request):
    if request.method == 'POST':
        username = request.POST['username']
        email = request.POST['email']
        password = request.POST['password']
        password_confirm = request.POST['password_confirm']
        if password == password_confirm:
            try:
                user = User.objects.create_user(username, email, password)
                Driver.objects.create(
                    user=user,
                    surname=request.POST['surname'],
                    middle_name=request.POST['middle_name'],
                    phone_number=request.POST['phone_number'],
                    national_id=request.POST['national_id'],
                    dl_number=request.POST['dl_number'],
                    dl_class=request.POST['dl_class']
                )
                messages.success(request, 'Driver registered successfully')
                return redirect('transport:driver_login')
            except:
                messages.error(request, 'Error registering driver')
        else:
            messages.error(request, 'Passwords do not match')
    return render(request, 'driver/register.html')

def driver_login(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username=username, password=password)
        if user is not None and hasattr(user, 'driver'):
            login(request, user)
            return redirect('transport:driver_dashboard')
        messages.error(request, 'Invalid credentials or not a driver')
    return render(request, 'driver/login.html')

@login_required
def driver_dashboard(request):
    if not hasattr(request.user, 'driver'):
        return redirect('transport:home')
    driver = request.user.driver
    bus = Bus.objects.filter(driver=driver).first()
    checkpoints = Checkpoint.objects.filter(route=bus.route) if bus else []
    return render(request, 'driver/driver_dashboard.html', {
        'driver': driver,
        'bus': bus,
        'checkpoints': checkpoints
    })

@login_required
def driver_map(request):
    if not hasattr(request.user, 'driver'):
        return redirect('transport:home')
    driver = request.user.driver
    bus = Bus.objects.filter(driver=driver).first()
    checkpoints = Checkpoint.objects.filter(route=bus.route) if bus else []
    return render(request, 'driver/map.html', {
        'bus': bus,
        'checkpoints': checkpoints
    })

@login_required
def driver_ratings(request):
    if not hasattr(request.user, 'driver'):
        return redirect('transport:home')
    driver = request.user.driver
    ratings = DriverRating.objects.filter(driver=driver)
    avg_rating = ratings.aggregate(Avg('rating'))['rating__avg'] or 0
    return render(request, 'driver/ratings.html', {
        'ratings': ratings,
        'avg_rating': round(avg_rating, 2)
    })

@login_required
def driver_complaints(request):
    if not hasattr(request.user, 'driver'):
        return redirect('transport:home')
    driver = request.user.driver
    complaints = Complaint.objects.filter(driver=driver)
    return render(request, 'driver/complaints.html', {'complaints': complaints})

# Customer Views
def customer_register(request):
    if request.method == 'POST':
        username = request.POST['username']
        email = request.POST['email']
        password = request.POST['password']
        password_confirm = request.POST['password_confirm']
        if password == password_confirm:
            try:
                user = User.objects.create_user(username, email, password)
                Customer.objects.create(
                    user=user,
                    surname=request.POST['surname'],
                    middle_name=request.POST['middle_name'],
                    phone_number=request.POST['phone_number']
                )
                messages.success(request, 'Customer registered successfully')
                return redirect('transport:customer_login')
            except:
                messages.error(request, 'Error registering customer')
        else:
            messages.error(request, 'Passwords do not match')
    return render(request, 'customer/register.html')

def customer_login(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username=username, password=password)
        if user is not None and hasattr(user, 'customer'):
            login(request, user)
            return redirect('transport:customer_dashboard')
        messages.error(request, 'Invalid credentials or not a customer')
    return render(request, 'customer/login.html')

@login_required
def customer_dashboard(request):
    if not hasattr(request.user, 'customer'):
        return redirect('transport:home')
    routes = Route.objects.all()
    checkpoints = Checkpoint.objects.all()
    if request.method == 'POST':
        start_checkpoint_id = request.POST['start_checkpoint']
        end_checkpoint_id = request.POST['end_checkpoint']
        fare = Fare.objects.get(start_checkpoint_id=start_checkpoint_id, end_checkpoint_id=end_checkpoint_id)
        Payment.objects.create(
            customer=request.user.customer,
            bus=Bus.objects.first(),  # Mock bus selection
            amount=fare.amount,
            start_checkpoint_id=start_checkpoint_id,
            end_checkpoint_id=end_checkpoint_id
        )
        messages.success(request, f'Payment of {fare.amount} processed successfully')
    return render(request, 'customer/customer_dashboard.html', {
        'routes': routes,
        'checkpoints': checkpoints
    })

@login_required
def customer_map(request):
    if not hasattr(request.user, 'customer'):
        return redirect('transport:home')
    routes = Route.objects.all()
    checkpoints = Checkpoint.objects.all()
    buses = Bus.objects.all()
    return render(request, 'customer/map.html', {
        'routes': routes,
        'checkpoints': checkpoints,
        'buses': buses
    })

@login_required
def delete_customer_account(request):
    if not hasattr(request.user, 'customer'):
        return redirect('transport:home')
    if request.method == 'POST':
        password = request.POST['password']
        user = authenticate(request, username=request.user.username, password=password)
        if user is not None:
            user.delete()
            messages.success(request, 'Account deleted successfully')
            return redirect('transport:home')
        messages.error(request, 'Invalid password')
    return render(request, 'customer/delete_account.html')

@login_required
def rate_driver(request):
    if not hasattr(request.user, 'customer'):
        return redirect('transport:home')
    if request.method == 'POST':
        driver_id = request.POST['driver_id']
        rating = int(request.POST['rating'])
        comment = request.POST['comment']
        DriverRating.objects.create(
            driver_id=driver_id,
            customer=request.user.customer,
            rating=rating,
            comment=comment
        )
        messages.success(request, 'Rating submitted successfully')
        return redirect('transport:customer_dashboard')
    drivers = Driver.objects.filter(is_approved=True)
    return render(request, 'customer/rate_driver.html', {'drivers': drivers})

@login_required
def submit_complaint(request):
    if not hasattr(request.user, 'customer'):
        return redirect('transport:home')
    if request.method == 'POST':
        driver_id = request.POST.get('driver_id')
        description = request.POST['description']
        Complaint.objects.create(
            customer=request.user.customer,
            driver_id=driver_id if driver_id else None,
            description=description
        )
        messages.success(request, 'Complaint submitted successfully')
        return redirect('transport:customer_dashboard')
    drivers = Driver.objects.filter(is_approved=True)
    return render(request, 'customer/submit_complaint.html', {'drivers': drivers})

@login_required
def customer_complaints(request):
    if not hasattr(request.user, 'customer'):
        return redirect('transport:home')
    complaints = Complaint.objects.filter(customer=request.user.customer)
    return render(request, 'customer/complaints.html', {'complaints': complaints})